package sk.abilityweapons.models;

import org.bukkit.Material;

public enum WeaponType {
    FIRE_SWORD("FIRE_SWORD", Material.NETHERITE_SWORD),
    THUNDER_AXE("THUNDER_AXE", Material.NETHERITE_AXE),
    ICE_BOW("ICE_BOW", Material.BOW),
    SHADOW_TRIDENT("SHADOW_TRIDENT", Material.TRIDENT),
    STORM_MACE("STORM_MACE", Material.MACE),
    VOID_CROSSBOW("VOID_CROSSBOW", Material.CROSSBOW);

    private final String configKey;
    private final Material material;

    WeaponType(String configKey, Material material) {
        this.configKey = configKey;
        this.material = material;
    }

    public String getConfigKey() { return configKey; }
    public Material getMaterial() { return material; }

    public static WeaponType fromString(String name) {
        if (name == null) return null;
        try {
            return valueOf(name.toUpperCase().trim());
        } catch (IllegalArgumentException e) {
            return null;
        }
    }
}
