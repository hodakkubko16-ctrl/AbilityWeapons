package sk.abilityweapons.managers;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.entity.Player;
import sk.abilityweapons.AbilityWeapons;
import sk.abilityweapons.models.WeaponType;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class CooldownManager {

    private final AbilityWeapons plugin;
    private final Map<UUID, Map<String, Long>> cooldowns = new HashMap<>();

    public CooldownManager(AbilityWeapons plugin) {
        this.plugin = plugin;
    }

    public boolean isOnCooldown(Player player, WeaponType type, boolean ability2) {
        return getRemainingSeconds(player, type, ability2) > 0;
    }

    public long getRemainingSeconds(Player player, WeaponType type, boolean ability2) {
        String key = type.name() + "_" + (ability2 ? "2" : "1");
        Map<String, Long> map = cooldowns.get(player.getUniqueId());
        if (map == null) return 0;
        Long last = map.get(key);
        if (last == null) return 0;

        int cooldownSec = plugin.getWeaponManager().getCooldown(type, ability2);
        long remaining = (last + cooldownSec * 1000L - System.currentTimeMillis()) / 1000L;
        return Math.max(0, remaining);
    }

    public void setCooldown(Player player, WeaponType type, boolean ability2) {
        String key = type.name() + "_" + (ability2 ? "2" : "1");
        cooldowns.computeIfAbsent(player.getUniqueId(), k -> new HashMap<>()).put(key, System.currentTimeMillis());
    }

    public void sendCooldownMessage(Player player, long remaining) {
        if (!plugin.getConfig().getBoolean("settings.actionbar-cooldown", true)) return;
        Component msg = Component.text("Cooldown: ", NamedTextColor.RED)
                .append(Component.text(remaining + "s", NamedTextColor.YELLOW, TextDecoration.BOLD));
        player.sendActionBar(msg);
    }

    public void clear(Player player) { cooldowns.remove(player.getUniqueId()); }
}
