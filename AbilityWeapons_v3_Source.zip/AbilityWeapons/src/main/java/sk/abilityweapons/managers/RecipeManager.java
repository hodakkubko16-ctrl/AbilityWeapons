package sk.abilityweapons.managers;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.Recipe;
import org.bukkit.inventory.ShapedRecipe;
import sk.abilityweapons.AbilityWeapons;
import sk.abilityweapons.models.WeaponType;

import java.util.Iterator;

public class RecipeManager {

    private final AbilityWeapons plugin;

    public RecipeManager(AbilityWeapons plugin) {
        this.plugin = plugin;
    }

    public void registerAll() {
        register("fire_sword", WeaponType.FIRE_SWORD, new String[]{"BBB", "BNB", "SSS"}, map -> {
            map.put('B', Material.BLAZE_ROD);
            map.put('N', Material.NETHERITE_SWORD);
            map.put('S', Material.NETHERITE_SCRAP);
        });

        register("thunder_axe", WeaponType.THUNDER_AXE, new String[]{"LCL", "LAL", " S "}, map -> {
            map.put('L', Material.LIGHTNING_ROD);
            map.put('C', Material.CREEPER_HEAD);
            map.put('A', Material.NETHERITE_AXE);
            map.put('S', Material.NETHERITE_INGOT);
        });

        register("ice_bow", WeaponType.ICE_BOW, new String[]{"PFP", "FBF", "PFP"}, map -> {
            map.put('P', Material.PACKED_ICE);
            map.put('F', Material.FEATHER);
            map.put('B', Material.BOW);
        });

        register("shadow_trident", WeaponType.SHADOW_TRIDENT, new String[]{"EEE", "ETE", "SSS"}, map -> {
            map.put('E', Material.ENDER_PEARL);
            map.put('T', Material.TRIDENT);
            map.put('S', Material.ECHO_SHARD);
        });

        register("storm_mace", WeaponType.STORM_MACE, new String[]{"BWB", "WMW", "BWB"}, map -> {
            map.put('B', Material.BREEZE_ROD);
            map.put('W', Material.WIND_CHARGE);
            map.put('M', Material.MACE);
        });

        register("void_crossbow", WeaponType.VOID_CROSSBOW, new String[]{"OOO", "OCO", "EEE"}, map -> {
            map.put('O', Material.OBSIDIAN);
            map.put('C', Material.CROSSBOW);
            map.put('E', Material.ENDER_EYE);
        });
    }

    private void register(String keyName, WeaponType type, String[] shape, java.util.function.Consumer<java.util.Map<Character, Material>> ingredients) {
        ItemStack result = plugin.getWeaponManager().createWeapon(type);
        NamespacedKey key = new NamespacedKey(plugin, keyName);
        ShapedRecipe recipe = new ShapedRecipe(key, result);
        recipe.shape(shape);

        java.util.Map<Character, Material> map = new java.util.HashMap<>();
        ingredients.accept(map);
        for (var entry : map.entrySet()) {
            recipe.setIngredient(entry.getKey(), entry.getValue());
        }

        Bukkit.removeRecipe(key);
        Bukkit.addRecipe(recipe);
    }

    public void unregisterAll() {
        Iterator<Recipe> it = Bukkit.recipeIterator();
        while (it.hasNext()) {
            Recipe recipe = it.next();
            if (recipe instanceof ShapedRecipe shaped) {
                if (shaped.getKey().getNamespace().equalsIgnoreCase("abilityweapons")) {
                    it.remove();
                }
            }
        }
    }
}
