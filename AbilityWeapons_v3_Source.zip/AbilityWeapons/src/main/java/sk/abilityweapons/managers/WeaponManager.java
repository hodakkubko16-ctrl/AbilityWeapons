package sk.abilityweapons.managers;

import net.kyori.adventure.text.Component;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import sk.abilityweapons.AbilityWeapons;
import sk.abilityweapons.models.WeaponType;

import java.util.ArrayList;
import java.util.List;

public class WeaponManager {

    private final AbilityWeapons plugin;
    private final NamespacedKey weaponKey;

    public WeaponManager(AbilityWeapons plugin) {
        this.plugin = plugin;
        this.weaponKey = new NamespacedKey(plugin, "weapon_type");
    }

    public void reload() {}

    public ItemStack createWeapon(WeaponType type) {
        ConfigurationSection section = plugin.getConfig().getConfigurationSection("weapons." + type.getConfigKey());
        if (section == null) {
            return new ItemStack(type.getMaterial());
        }

        ItemStack item = new ItemStack(type.getMaterial());
        ItemMeta meta = item.getItemMeta();
        if (meta == null) return item;

        String displayName = section.getString("display-name", "&f" + type.name());
        meta.displayName(LegacyColor.parse(displayName));

        List<String> loreRaw = section.getStringList("lore");
        List<Component> lore = new ArrayList<>();
        for (String line : loreRaw) {
            lore.add(LegacyColor.parse(line));
        }
        meta.lore(lore);

        int cmd = section.getInt("custom-model-data", 0);
        if (cmd > 0) {
            meta.setCustomModelData(cmd);
        }

        meta.setUnbreakable(true);
        meta.addItemFlags(ItemFlag.HIDE_ATTRIBUTES, ItemFlag.HIDE_ENCHANTS, ItemFlag.HIDE_UNBREAKABLE);
        meta.getPersistentDataContainer().set(weaponKey, PersistentDataType.STRING, type.name());

        item.setItemMeta(meta);
        return item;
    }

    public WeaponType getWeaponType(ItemStack item) {
        if (item == null || item.getType() == Material.AIR || !item.hasItemMeta()) {
            return null;
        }
        String id = item.getItemMeta().getPersistentDataContainer().get(weaponKey, PersistentDataType.STRING);
        return WeaponType.fromString(id);
    }

    public boolean isWeapon(ItemStack item) { return getWeaponType(item) != null; }
    public int getCooldown(WeaponType type, boolean ability2) {
        return plugin.getConfig().getInt("weapons." + type.getConfigKey() + (ability2 ? ".ability2-cooldown" : ".ability1-cooldown"), 12);
    }

    public double getDamage(WeaponType type, boolean ability2) {
        return plugin.getConfig().getDouble("weapons." + type.getConfigKey() + (ability2 ? ".ability2-damage" : ".ability1-damage"), 10.0);
    }
}
