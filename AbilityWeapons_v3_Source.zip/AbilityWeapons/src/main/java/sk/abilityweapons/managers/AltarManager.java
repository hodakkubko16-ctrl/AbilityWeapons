package sk.abilityweapons.managers;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.*;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Item;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.util.Vector;
import sk.abilityweapons.AbilityWeapons;
import sk.abilityweapons.models.WeaponType;

public class AltarManager {

    private final AbilityWeapons plugin;
    private Location altarLocation;
    private Item floatingWeaponItem;
    private WeaponType currentCraftedType;
    private BukkitTask levitationTask;
    private BukkitTask timerTask;

    public AltarManager(AbilityWeapons plugin) {
        this.plugin = plugin;
        loadAltarLocation();
    }

    public void loadAltarLocation() {
        if (plugin.getConfig().getBoolean("altar.set", false)) {
            String wName = plugin.getConfig().getString("altar.world", "world");
            World w = Bukkit.getWorld(wName);
            if (w != null) {
                double x = plugin.getConfig().getDouble("altar.x");
                double y = plugin.getConfig().getDouble("altar.y");
                double z = plugin.getConfig().getDouble("altar.z");
                altarLocation = new Location(w, x, y, z);
            }
        }
    }

    public void setAltarLocation(Location loc) {
        this.altarLocation = loc.clone();
        plugin.getConfig().set("altar.world", loc.getWorld().getName());
        plugin.getConfig().set("altar.x", loc.getBlockX());
        plugin.getConfig().set("altar.y", loc.getBlockY());
        plugin.getConfig().set("altar.z", loc.getBlockZ());
        plugin.getConfig().set("altar.set", true);
        plugin.saveConfig();
    }

    public Location getAltarLocation() { return altarLocation; }
    public boolean isAltarSet() { return altarLocation != null && plugin.getConfig().getBoolean("altar.set", false); }

    public boolean isNearAltar(Location loc) {
        if (!isAltarSet() || loc == null || loc.getWorld() == null) return false;
        if (!loc.getWorld().equals(altarLocation.getWorld())) return false;
        return loc.distance(altarLocation) <= 4.5;
    }

    public boolean isCraftingActive() {
        return floatingWeaponItem != null && floatingWeaponItem.isValid();
    }

    public void startCraftRitual(Player crafter, WeaponType type) {
        this.currentCraftedType = type;

        World world = altarLocation.getWorld();
        Location floatLoc = altarLocation.clone().add(0.5, 3.0, 0.5);

        ItemStack weaponItem = plugin.getWeaponManager().createWeapon(type);
        floatingWeaponItem = world.dropItem(floatLoc, weaponItem);
        floatingWeaponItem.setGravity(false);
        floatingWeaponItem.setPickupDelay(999999);
        floatingWeaponItem.setInvulnerable(true);
        floatingWeaponItem.setGlowing(true);
        floatingWeaponItem.setVelocity(new Vector(0, 0, 0));

        Component prefix = LegacyColor.parse(plugin.getConfig().getString("settings.prefix", "&8[&6AW&8] "));
        Bukkit.broadcast(prefix.append(Component.text("⚔️ Hráč ", NamedTextColor.GOLD))
                .append(Component.text(crafter.getName(), NamedTextColor.YELLOW, TextDecoration.BOLD))
                .append(Component.text(" práve vycraftil ", NamedTextColor.GOLD))
                .append(Component.text(type.name(), NamedTextColor.RED, TextDecoration.BOLD))
                .append(Component.text("! Zbraň levituje nad Oltárom!", NamedTextColor.GOLD)));

        levitationTask = new BukkitRunnable() {
            double angle = 0;
            @Override
            public void run() {
                if (floatingWeaponItem == null || !floatingWeaponItem.isValid()) {
                    cancel();
                    return;
                }
                angle += 0.15;
                Location loc = floatingWeaponItem.getLocation();
                loc.setY(floatLoc.getY() + Math.sin(angle) * 0.2);
                floatingWeaponItem.teleport(loc);

                world.spawnParticle(Particle.END_ROD, loc.clone().add(0, 0.3, 0), 3, 0.2, 0.2, 0.2, 0.02);
                world.spawnParticle(Particle.ENCHANT, loc.clone().add(0, 0.3, 0), 8, 0.4, 0.4, 0.4, 0.1);
                world.spawnParticle(Particle.FLAME, loc.clone().add(0, 0.1, 0), 2, 0.1, 0.1, 0.1, 0.01);
            }
        }.runTaskTimer(plugin, 0L, 2L);

        timerTask = new BukkitRunnable() {
            int elapsedMinutes = 0;
            @Override
            public void run() {
                elapsedMinutes += 5;
                if (elapsedMinutes == 5) {
                    Bukkit.broadcast(prefix.append(Component.text("🔍 [LEAK 1/3] Oltár X: ", NamedTextColor.AQUA))
                            .append(Component.text(altarLocation.getBlockX(), NamedTextColor.YELLOW, TextDecoration.BOLD))
                            .append(Component.text(" | Z: ??? | Svet: " + altarLocation.getWorld().getName(), NamedTextColor.GRAY)));
                } else if (elapsedMinutes == 10) {
                    Bukkit.broadcast(prefix.append(Component.text("🔍 [LEAK 2/3] Oltár X: ??? | Z: ", NamedTextColor.AQUA))
                            .append(Component.text(altarLocation.getBlockZ(), NamedTextColor.YELLOW, TextDecoration.BOLD))
                            .append(Component.text(" | Svet: " + altarLocation.getWorld().getName(), NamedTextColor.GRAY)));
                } else if (elapsedMinutes == 15) {
                    Bukkit.broadcast(prefix.append(Component.text("🚨 [FULL LEAK] Oltár súradnice: ", NamedTextColor.RED, TextDecoration.BOLD))
                            .append(Component.text("X: " + altarLocation.getBlockX() + " Y: " + altarLocation.getBlockY() + " Z: " + altarLocation.getBlockZ(), NamedTextColor.YELLOW, TextDecoration.BOLD)));
                } else if (elapsedMinutes >= 20) {
                    releaseWeaponFromSky();
                    cancel();
                }
            }
        }.runTaskTimer(plugin, 5 * 60 * 20L, 5 * 60 * 20L);
    }

    private void releaseWeaponFromSky() {
        if (levitationTask != null) levitationTask.cancel();

        if (floatingWeaponItem != null && floatingWeaponItem.isValid()) {
            World w = floatingWeaponItem.getWorld();
            Location targetLoc = altarLocation.clone().add(0.5, 1.0, 0.5);

            w.strikeLightningEffect(targetLoc);
            w.playSound(targetLoc, Sound.ENTITY_LIGHTNING_BOLT_THUNDER, 1.5f, 0.8f);
            w.playSound(targetLoc, Sound.ENTITY_GENERIC_EXPLODE, 1.2f, 1.0f);
            w.spawnParticle(Particle.EXPLOSION_EMITTER, targetLoc, 2);

            floatingWeaponItem.setGravity(true);
            floatingWeaponItem.setPickupDelay(0);
            floatingWeaponItem.teleport(targetLoc);

            Component prefix = LegacyColor.parse(plugin.getConfig().getString("settings.prefix", "&8[&6AW&8] "));
            Bukkit.broadcast(prefix.append(Component.text("⚡ ZBRAŇ ", NamedTextColor.GOLD, TextDecoration.BOLD))
                    .append(Component.text(currentCraftedType.name(), NamedTextColor.RED, TextDecoration.BOLD))
                    .append(Component.text(" SPADLA Z NEBA NA OLTÁRI! Hoci-ktorý hráč si ju môže zobrať!", NamedTextColor.GREEN, TextDecoration.BOLD)));
        }
    }

    public boolean isWeaponOnServer(WeaponType type) {
        if (currentCraftedType == type && isCraftingActive()) return true;
        for (Player p : Bukkit.getOnlinePlayers()) {
            for (ItemStack item : p.getInventory().getContents()) {
                if (plugin.getWeaponManager().getWeaponType(item) == type) return true;
            }
            for (ItemStack item : p.getEnderChest().getContents()) {
                if (plugin.getWeaponManager().getWeaponType(item) == type) return true;
            }
        }
        for (World world : Bukkit.getWorlds()) {
            for (Entity entity : world.getEntities()) {
                if (entity instanceof Item itemEntity) {
                    if (plugin.getWeaponManager().getWeaponType(itemEntity.getItemStack()) == type) return true;
                }
            }
        }
        return false;
    }
}
