package sk.abilityweapons;

import org.bukkit.plugin.java.JavaPlugin;
import sk.abilityweapons.commands.MainCommand;
import sk.abilityweapons.listeners.AbilityListener;
import sk.abilityweapons.managers.AltarManager;
import sk.abilityweapons.managers.CooldownManager;
import sk.abilityweapons.managers.RecipeManager;
import sk.abilityweapons.managers.WeaponManager;

public class AbilityWeapons extends JavaPlugin {

    private static AbilityWeapons instance;
    private WeaponManager weaponManager;
    private CooldownManager cooldownManager;
    private RecipeManager recipeManager;
    private AltarManager altarManager;

    @Override
    public void onEnable() {
        instance = this;
        saveDefaultConfig();

        weaponManager = new WeaponManager(this);
        cooldownManager = new CooldownManager(this);
        altarManager = new AltarManager(this);
        recipeManager = new RecipeManager(this);

        recipeManager.registerAll();
        getServer().getPluginManager().registerEvents(new AbilityListener(this), this);

        MainCommand cmd = new MainCommand(this);
        getCommand("abilityweapons").setExecutor(cmd);
        getCommand("abilityweapons").setTabCompleter(cmd);

        getLogger().info("============================================");
        getLogger().info("  AbilityWeapons v3.0 - Levitating Altar Ritual");
        getLogger().info("============================================");
    }

    @Override
    public void onDisable() {
        if (recipeManager != null) {
            recipeManager.unregisterAll();
        }
        getLogger().info("AbilityWeapons disabled.");
    }

    public static AbilityWeapons getInstance() { return instance; }
    public WeaponManager getWeaponManager() { return weaponManager; }
    public CooldownManager getCooldownManager() { return cooldownManager; }
    public AltarManager getAltarManager() { return altarManager; }

    public void reloadPlugin() {
        reloadConfig();
        weaponManager.reload();
        altarManager.loadAltarLocation();
        recipeManager.unregisterAll();
        recipeManager.registerAll();
        getLogger().info("Config, Altar & Recipes reloaded.");
    }
}
