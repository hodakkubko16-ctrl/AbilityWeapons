package sk.abilityweapons.listeners;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.*;
import org.bukkit.entity.*;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.inventory.CraftItemEvent;
import org.bukkit.event.inventory.PrepareItemCraftEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerSwapHandItemsEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;
import sk.abilityweapons.AbilityWeapons;
import sk.abilityweapons.managers.AltarManager;
import sk.abilityweapons.managers.CooldownManager;
import sk.abilityweapons.managers.WeaponManager;
import sk.abilityweapons.models.WeaponType;

public class AbilityListener implements Listener {

    private final AbilityWeapons plugin;
    private final WeaponManager weaponManager;
    private final CooldownManager cooldownManager;

    public AbilityListener(AbilityWeapons plugin) {
        this.plugin = plugin;
        this.weaponManager = plugin.getWeaponManager();
        this.cooldownManager = plugin.getCooldownManager();
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onPrepareCraft(PrepareItemCraftEvent event) {
        ItemStack result = event.getInventory().getResult();
        WeaponType type = weaponManager.getWeaponType(result);
        if (type == null) return;

        if (!(event.getView().getPlayer() instanceof Player player)) return;
        AltarManager altar = plugin.getAltarManager();

        if (!altar.isAltarSet() || !altar.isNearAltar(player.getLocation()) || altar.isCraftingActive() || altar.isWeaponOnServer(type)) {
            event.getInventory().setResult(null);
        }
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onCraft(CraftItemEvent event) {
        ItemStack result = event.getCurrentItem();
        WeaponType type = weaponManager.getWeaponType(result);
        if (type == null) return;

        event.setCancelled(true);
        event.getInventory().setResult(null);

        if (event.getWhoClicked() instanceof Player player) {
            plugin.getAltarManager().startCraftRitual(player, type);
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onSwapHands(PlayerSwapHandItemsEvent event) {
        Player player = event.getPlayer();
        ItemStack mainHand = player.getInventory().getItemInMainHand();

        WeaponType type = weaponManager.getWeaponType(mainHand);
        if (type == null) return;

        event.setCancelled(true);
        boolean shift = player.isSneaking();

        if (cooldownManager.isOnCooldown(player, type, shift)) {
            cooldownManager.sendCooldownMessage(player, cooldownManager.getRemainingSeconds(player, type, shift));
            return;
        }

        cooldownManager.setCooldown(player, type, shift);

        if (shift) {
            executeAbility2(player, type);
        } else {
            executeAbility1(player, type);
        }
    }

    private void executeAbility1(Player player, WeaponType type) {
        Location loc = player.getLocation();
        World world = player.getWorld();
        double damage = weaponManager.getDamage(type, false);

        switch (type) {
            case FIRE_SWORD -> {
                player.sendActionBar(Component.text("✦ Ohnivá Vlna ✦", NamedTextColor.RED, TextDecoration.BOLD));
                world.playSound(loc, Sound.ENTITY_BLAZE_SHOOT, 1.2f, 0.7f);
                for (Entity entity : player.getNearbyEntities(7.5, 4.0, 7.5)) {
                    if (entity instanceof LivingEntity living && entity != player && !(entity instanceof ArmorStand)) {
                        living.setFireTicks(160);
                        living.damage(damage, player);
                    }
                }
                for (int i = 0; i < 360; i += 8) {
                    double rad = Math.toRadians(i);
                    Location pLoc = loc.clone().add(Math.cos(rad) * 5.0, 0.3, Math.sin(rad) * 5.0);
                    world.spawnParticle(Particle.FLAME, pLoc, 5, 0.1, 0.1, 0.1, 0.02);
                }
            }
            case THUNDER_AXE -> {
                player.sendActionBar(Component.text("⚡ Thorov Vrh ⚡", NamedTextColor.YELLOW, TextDecoration.BOLD));
                world.playSound(loc, Sound.ITEM_TRIDENT_THROW, 1.2f, 0.6f);

                ArmorStand stand = world.spawn(loc.clone().add(0, 1, 0), ArmorStand.class, s -> {
                    s.setInvisible(true);
                    s.setMarker(true);
                    s.setGravity(false);
                    s.getEquipment().setItemInMainHand(weaponManager.createWeapon(WeaponType.THUNDER_AXE));
                });

                Vector dir = loc.getDirection().normalize().multiply(1.2);
                new BukkitRunnable() {
                    int step = 0;
                    @Override
                    public void run() {
                        if (step++ > 15 || stand.isDead()) {
                            stand.remove();
                            cancel();
                            return;
                        }
                        stand.teleport(stand.getLocation().add(dir));
                        world.spawnParticle(Particle.ELECTRIC_SPARK, stand.getLocation(), 15, 0.3, 0.3, 0.3, 0.1);

                        for (Entity e : stand.getNearbyEntities(1.8, 1.8, 1.8)) {
                            if (e instanceof LivingEntity living && e != player && !(e instanceof ArmorStand)) {
                                world.strikeLightningEffect(living.getLocation());
                                living.damage(damage, player);
                            }
                        }
                    }
                }.runTaskTimer(plugin, 0L, 1L);
            }
            case ICE_BOW -> {
                player.sendActionBar(Component.text("❄ Trojitý Ľadový Šíp ❄", NamedTextColor.AQUA, TextDecoration.BOLD));
                world.playSound(loc, Sound.ENTITY_ARROW_SHOOT, 1.0f, 0.6f);
                Vector base = player.getLocation().getDirection().normalize();
                for (int i = -1; i <= 1; i++) {
                    Vector dir = base.clone().rotateAroundY(Math.toRadians(i * 10));
                    Arrow arrow = player.launchProjectile(Arrow.class, dir.multiply(2.8));
                    arrow.setDamage(damage);
                    arrow.setColor(Color.fromRGB(100, 220, 255));
                }
            }
            case SHADOW_TRIDENT -> {
                player.sendActionBar(Component.text("✦ Tieňový Skok ✦", NamedTextColor.DARK_PURPLE, TextDecoration.BOLD));
                LivingEntity target = getLookTarget(player, 14);
                if (target != null) {
                    player.teleport(target.getLocation().add(target.getLocation().getDirection().multiply(-1.5)));
                    target.damage(damage, player);
                } else {
                    player.teleport(player.getLocation().add(player.getLocation().getDirection().multiply(7.0)));
                }
                world.spawnParticle(Particle.PORTAL, player.getLocation(), 80, 0.5, 1.0, 0.5, 0.2);
            }
            case STORM_MACE -> {
                player.sendActionBar(Component.text("✦ Shockwave ✦", NamedTextColor.LIGHT_PURPLE, TextDecoration.BOLD));
                world.playSound(loc, Sound.ENTITY_GENERIC_EXPLODE, 1.0f, 1.2f);
                for (Entity entity : player.getNearbyEntities(6.5, 3.5, 6.5)) {
                    if (entity instanceof LivingEntity living && entity != player && !(entity instanceof ArmorStand)) {
                        living.damage(damage, player);
                        living.setVelocity(living.getLocation().toVector().subtract(loc.toVector()).normalize().multiply(1.4).setY(0.5));
                    }
                }
                world.spawnParticle(Particle.EXPLOSION_EMITTER, loc, 3);
            }
            case VOID_CROSSBOW -> {
                player.sendActionBar(Component.text("✦ Void Shot ✦", NamedTextColor.DARK_GRAY, TextDecoration.BOLD));
                world.playSound(loc, Sound.ENTITY_SHULKER_SHOOT, 1.0f, 0.7f);
                Arrow arrow = player.launchProjectile(Arrow.class, player.getLocation().getDirection().multiply(3.0));
                arrow.setDamage(damage);
                arrow.setColor(Color.fromRGB(20, 0, 40));
            }
        }
    }

    private void executeAbility2(Player player, WeaponType type) {
        Location loc = player.getLocation();
        World world = player.getWorld();
        double damage = weaponManager.getDamage(type, true);

        switch (type) {
            case FIRE_SWORD -> {
                player.sendActionBar(Component.text("🔥 Ohnivý Dash 🔥", NamedTextColor.GOLD, TextDecoration.BOLD));
                player.setVelocity(player.getLocation().getDirection().normalize().multiply(2.2).setY(0.35));
                new BukkitRunnable() {
                    int t = 0;
                    @Override
                    public void run() {
                        if (t++ > 10 || !player.isOnline()) { cancel(); return; }
                        world.spawnParticle(Particle.FLAME, player.getLocation(), 25, 0.4, 0.4, 0.4, 0.05);
                        for (Entity e : player.getNearbyEntities(2.5, 2.0, 2.5)) {
                            if (e instanceof LivingEntity living && e != player && !(e instanceof ArmorStand)) {
                                living.setFireTicks(100);
                                living.damage(damage, player);
                            }
                        }
                    }
                }.runTaskTimer(plugin, 0L, 2L);
            }
            case THUNDER_AXE -> {
                player.sendActionBar(Component.text("⚡ Cataclysmic Tempest ⚡", NamedTextColor.GOLD, TextDecoration.BOLD));
                player.setVelocity(new Vector(0, 1.3, 0));
                world.playSound(loc, Sound.ENTITY_LIGHTNING_BOLT_THUNDER, 1.5f, 0.5f);

                new BukkitRunnable() {
                    int ticks = 0;
                    @Override
                    public void run() {
                        if (ticks++ > 80 || !player.isOnline()) { cancel(); return; }
                        Location center = player.getLocation();
                        world.spawnParticle(Particle.CLOUD, center.clone().add(0, 4, 0), 40, 6.0, 0.5, 6.0, 0.05);

                        if (ticks % 5 == 0) {
                            double rx = (Math.random() - 0.5) * 12;
                            double rz = (Math.random() - 0.5) * 12;
                            Location strikeLoc = center.clone().add(rx, 0, rz);
                            world.strikeLightningEffect(strikeLoc);

                            for (Entity e : world.getNearbyEntities(strikeLoc, 3.0, 3.0, 3.0)) {
                                if (e instanceof LivingEntity living && e != player && !(e instanceof ArmorStand)) {
                                    living.damage(damage * 0.4, player);
                                    living.setVelocity(new Vector(0, 0.4, 0));
                                }
                            }
                        }
                    }
                }.runTaskTimer(plugin, 10L, 1L);
            }
            case ICE_BOW -> {
                player.sendActionBar(Component.text("❄ Ľadové Tornádo ❄", NamedTextColor.DARK_AQUA, TextDecoration.BOLD));
                for (Entity e : player.getNearbyEntities(9.0, 5.0, 9.0)) {
                    if (e instanceof LivingEntity living && e != player && !(e instanceof ArmorStand)) {
                        living.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, 120, 3));
                        living.damage(damage, player);
                    }
                }
            }
            case SHADOW_TRIDENT -> {
                player.sendActionBar(Component.text("🌑 Tieňový Závoj 🌑", NamedTextColor.LIGHT_PURPLE, TextDecoration.BOLD));
                player.addPotionEffect(new PotionEffect(PotionEffectType.INVISIBILITY, 120, 0));
                player.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, 120, 1));
            }
            case STORM_MACE -> {
                player.sendActionBar(Component.text("⚡ Sky Slam ⚡", NamedTextColor.LIGHT_PURPLE, TextDecoration.BOLD));
                player.setVelocity(new Vector(0, 1.6, 0));
                new BukkitRunnable() {
                    @Override
                    public void run() {
                        if (!player.isOnline()) return;
                        player.setVelocity(new Vector(0, -2.0, 0));
                        new BukkitRunnable() {
                            @Override
                            public void run() {
                                if (!player.isOnline()) return;
                                Location land = player.getLocation();
                                world.playSound(land, Sound.ENTITY_GENERIC_EXPLODE, 1.2f, 0.7f);
                                world.spawnParticle(Particle.EXPLOSION_EMITTER, land, 3);
                                for (Entity e : player.getNearbyEntities(8.0, 4.0, 8.0)) {
                                    if (e instanceof LivingEntity living && e != player && !(e instanceof ArmorStand)) {
                                        living.damage(damage, player);
                                    }
                                }
                            }
                        }.runTaskLater(plugin, 8L);
                    }
                }.runTaskLater(plugin, 10L);
            }
            case VOID_CROSSBOW -> {
                player.sendActionBar(Component.text("✦ Black Hole ✦", NamedTextColor.DARK_PURPLE, TextDecoration.BOLD));
                Location center = loc.clone().add(player.getLocation().getDirection().multiply(4.5)).add(0, 1, 0);
                new BukkitRunnable() {
                    int t = 0;
                    @Override
                    public void run() {
                        if (t++ > 40) { cancel(); return; }
                        world.spawnParticle(Particle.SQUID_INK, center, 15, 0.5, 0.5, 0.5, 0.05);
                        for (Entity e : center.getWorld().getNearbyEntities(center, 7.0, 5.0, 7.0)) {
                            if (e instanceof LivingEntity living && e != player && !(e instanceof ArmorStand)) {
                                living.setVelocity(center.toVector().subtract(living.getLocation().toVector()).normalize().multiply(0.4));
                                if (t % 8 == 0) living.damage(damage * 0.35, player);
                            }
                        }
                    }
                }.runTaskTimer(plugin, 0L, 1L);
            }
        }
    }

    @EventHandler
    public void onHit(EntityDamageByEntityEvent event) {
        if (event.getDamager() instanceof Player player && event.getEntity() instanceof LivingEntity victim) {
            ItemStack item = player.getInventory().getItemInMainHand();
            if (weaponManager.getWeaponType(item) == WeaponType.FIRE_SWORD) {
                victim.setFireTicks(Math.max(victim.getFireTicks(), 50));
            }
        }
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) { cooldownManager.clear(event.getPlayer()); }

    private LivingEntity getLookTarget(Player player, double range) {
        Entity target = player.getTargetEntity((int) Math.ceil(range));
        if (target instanceof LivingEntity living && !(target instanceof ArmorStand)) return living;
        return null;
    }
}
