package sk.abilityweapons.commands;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import sk.abilityweapons.AbilityWeapons;
import sk.abilityweapons.models.WeaponType;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class MainCommand implements CommandExecutor, TabCompleter {

    private final AbilityWeapons plugin;

    public MainCommand(AbilityWeapons plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.hasPermission("abilityweapons.admin")) {
            sender.sendMessage(Component.text("Nemáš oprávnenie!", NamedTextColor.RED));
            return true;
        }

        if (args.length == 0) {
            sendHelp(sender);
            return true;
        }

        switch (args[0].toLowerCase()) {
            case "give" -> handleGive(sender, args);
            case "setaltar" -> handleSetAltar(sender);
            case "list" -> handleList(sender);
            case "reload" -> {
                plugin.reloadPlugin();
                sender.sendMessage(Component.text("Plugin bol reloadnutý!", NamedTextColor.GREEN));
            }
            default -> sendHelp(sender);
        }
        return true;
    }

    private void handleSetAltar(CommandSender sender) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage(Component.text("Tento príkaz môže použiť len hráč!", NamedTextColor.RED));
            return;
        }
        plugin.getAltarManager().setAltarLocation(player.getLocation());
        player.sendMessage(Component.text("📍 Oltár bol úspešne nastavený na tvojich súradniciach!", NamedTextColor.GREEN, TextDecoration.BOLD));
    }

    private void handleGive(CommandSender sender, String[] args) {
        if (args.length < 3) {
            sender.sendMessage(Component.text("Použitie: /aw give <hráč> <zbraň>", NamedTextColor.YELLOW));
            return;
        }

        Player target = Bukkit.getPlayer(args[1]);
        if (target == null) {
            sender.sendMessage(Component.text("Hráč nie je online.", NamedTextColor.RED));
            return;
        }

        WeaponType type = WeaponType.fromString(args[2]);
        if (type == null) {
            sender.sendMessage(Component.text("Neznáma zbraň! Pozri /aw list", NamedTextColor.RED));
            return;
        }

        target.getInventory().addItem(plugin.getWeaponManager().createWeapon(type));
        sender.sendMessage(Component.text("Dal si " + type.name() + " hráčovi " + target.getName(), NamedTextColor.GREEN));
    }

    private void handleList(CommandSender sender) {
        sender.sendMessage(Component.text("===== Legendárne Zbrane (v3.0) =====", NamedTextColor.GOLD, TextDecoration.BOLD));
        for (WeaponType t : WeaponType.values()) {
            sender.sendMessage(Component.text("• " + t.name(), NamedTextColor.YELLOW));
        }
    }

    private void sendHelp(CommandSender sender) {
        sender.sendMessage(Component.text("===== AbilityWeapons v3.0 =====", NamedTextColor.GOLD, TextDecoration.BOLD));
        sender.sendMessage(Component.text("/aw setaltar – Nastaví Oltár na tvoju pozíciu", NamedTextColor.YELLOW));
        sender.sendMessage(Component.text("/aw give <hráč> <zbraň> – Dá zbraň hráčovi", NamedTextColor.YELLOW));
        sender.sendMessage(Component.text("/aw reload – Znovu načíta config a Oltár", NamedTextColor.YELLOW));
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (!sender.hasPermission("abilityweapons.admin")) return List.of();
        if (args.length == 1) return List.of("give", "setaltar", "list", "reload");
        if (args.length == 3 && args[0].equalsIgnoreCase("give")) {
            return Arrays.stream(WeaponType.values()).map(Enum::name).collect(Collectors.toList());
        }
        return List.of();
    }
}
